// App.js

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import store from './store';
import Dashboard from './components/Dashboard';
import Profile from './components/Profile';
import EducationDetails from './components/EducationDetails';
import Login from './components/login'; // Import the Login component

function App() {
  return (
    <Provider store={store}>
      <Router>
        <Routes>
          {/* Route to the Login page as the initial route */}
          <Route path="/" element={<Login />} />
          {/* Dashboard will only appear if logged in */}
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/education-details" element={<EducationDetails />} />
        </Routes>
      </Router>
    </Provider>
  );
}

export default App;
