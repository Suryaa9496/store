

export const setUser = (username) => {
    return {
      type: 'SET_USER',
      payload: username
    };
  };
  