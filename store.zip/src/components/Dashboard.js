
 import { Link } from 'react-router-dom';
import React from 'react';
import { useSelector } from 'react-redux';
import './dashboard.css'

const Dashboard = () => {
  const username = useSelector((state) => state.user.username);

  return (
    <div className='profile'>
      <div className='hlo'>
      <h1>Hello {username}</h1>
      </div>
      <div className='prof'>
      <Link to="/profile">Profile</Link>
      </div>
    </div>
  );
};

export default Dashboard;



