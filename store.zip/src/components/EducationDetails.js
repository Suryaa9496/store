
import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addCertification } from '../actions/certificationActions';

const EducationDetails = () => {
  const [newCertification, setNewCertification] = useState('');
  const dispatch = useDispatch();
  const certifications = useSelector(state => state.user.certifications);
  
    const education = useSelector(state => state.user.education); 

  const handleAddCertification = () => {
    dispatch(addCertification(newCertification));
    setNewCertification('');
  };

  return (
    <div>
      
      <div>
      <h2>Education Details</h2>
      <h3>Class 10th</h3>
      <p>Institute Name: {education.class10.instituteName}</p>
      <p>CGPA: {education.class10.cgpa}</p>

      <h3>Class 12th</h3>
      <p>Institute Name: {education.class12.instituteName}</p>
      <p>CGPA: {education.class12.cgpa}</p>
    </div>
      <h3>Certifications</h3>
      {certifications.map((cert, index) => (
        <p key={index}>{cert}</p>
      ))}
      <input
        type="text"
        value={newCertification}
        onChange={(e) => setNewCertification(e.target.value)}
      />
      <button onClick={handleAddCertification}>Add Certification</button>
    </div>
  );
};

export default EducationDetails;
