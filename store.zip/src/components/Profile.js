import React from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';

const Profile = () => {
  // Dummy data for profile
  const dummyProfileData = {
    name: 'George Philips',
    country: 'Austraila',
    gender: 'Male',
    pan: 'AUS098765'
  };

 
  const { name, country, gender, pan } = useSelector((state) => state.user);


  const profileData = name ? { name, country, gender, pan } : dummyProfileData;

  return (
    <div>
      <h2>Personal Details</h2>
      <p>Name: {profileData.name}</p>
      <p>Country: {profileData.country}</p>
      <p>Gender: {profileData.gender}</p>
      <p>Permanent Account Number: {profileData.pan}</p>
      
      {/* Add link to EducationDetails page */}
      <Link to="/education-details">Education Details</Link>
    </div>
  );
};

export default Profile;
