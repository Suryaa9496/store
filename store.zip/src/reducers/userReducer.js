// userReducer.js

const initialState = {
  name: '',
  country: '',
  gender: '',
  pan: '',
  certifications: [],
  education: {
    class10: {
      instituteName: 'Bhavans Elamakkara',
      cgpa: '8.8'
    },
    class12: {
      instituteName: 'SNDP Udayamperoor',
      cgpa: '9.3'
    }
  },
  username: '' // Add username field
};

const userReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'SET_USER': // Add case for SET_USER action
      return {
        ...state,
        username: action.payload
      };
    case 'ADD_CERTIFICATION':
      return {
        ...state,
        certifications: [...state.certifications, action.payload]
      };
    default:
      return state;
  }
};

export default userReducer;
